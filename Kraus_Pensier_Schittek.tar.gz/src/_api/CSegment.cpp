/*
 * CSegment.cpp
 *
 *  Created on: 22 d�c. 2009
 *      Author: girouxi
 */

#include "CSegment.h"

CSegment::CSegment() {
	// TODO Auto-generated constructor stub

}

CSegment::~CSegment() {
	// TODO Auto-generated destructor stub
}
